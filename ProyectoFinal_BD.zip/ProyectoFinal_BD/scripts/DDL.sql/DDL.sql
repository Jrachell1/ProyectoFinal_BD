-- DDL.sql
CREATE DATABASE Academia2022;
GO
USE Academia2022;

CREATE SCHEMA Seguridad;
GO

CREATE TABLE dbo.Alumnos (
    AlumnoID INT PRIMARY KEY IDENTITY,
    AlumnoNombre VARCHAR(100),
    AlumnoApellido VARCHAR(100)
);
GO

CREATE TABLE Seguridad.AuditoriaAccesos (
    AuditoriaID INT PRIMARY KEY IDENTITY,
    Usuario SYSNAME,
    Accion VARCHAR(50),
    Fecha DATETIME
);
GO