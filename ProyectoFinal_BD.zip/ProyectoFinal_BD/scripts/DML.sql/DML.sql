-- DML.sql
INSERT INTO dbo.Alumnos (AlumnoNombre, AlumnoApellido)
VALUES ('Carlos', 'L�pez'), ('Mar�a', 'Gonz�lez');

UPDATE dbo.Alumnos
SET AlumnoApellido = 'P�rez'
WHERE AlumnoID = 1;
