-- DCL.sql
CREATE ROLE AppReader;
CREATE ROLE AppWriter;
CREATE ROLE auditorBD;

GRANT SELECT ON dbo.Alumnos TO AppReader;
GRANT INSERT, UPDATE, DELETE ON dbo.Alumnos TO AppWriter;
GRANT SELECT ON Seguridad.AuditoriaAccesos TO auditorBD;