-- DQL.sql
CREATE VIEW dbo.VistaPromedioCursos
WITH SCHEMABINDING
AS
SELECT CursoID, COUNT(*) AS TotalAlumnos
FROM dbo.Matriculas
GROUP BY CursoID;
GO

SELECT * FROM dbo.VistaPromedioCursos;
