﻿/* =============================================================
   Script Maestro Idempotente: Proyecto Final - Academia2022
   Incluye: DDL, DML, DCL, DQL
   ============================================================= */

-- Si la base de datos no existe, crearla
IF DB_ID('Academia2022') IS NULL
BEGIN
    CREATE DATABASE Academia2022;
    PRINT '✅ Base de datos Academia2022 creada.';
END
ELSE
    PRINT 'ℹ️ La base de datos Academia2022 ya existe.';
GO

USE Academia2022;
GO

/* =============================================================
   1. CREACIÓN DE TABLAS PRINCIPALES
   ============================================================= */

-- Cursos
IF OBJECT_ID('dbo.Cursos', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Cursos (
        CursoID INT PRIMARY KEY,
        CursoNombre NVARCHAR(100) NOT NULL
    );
    PRINT '✅ Tabla dbo.Cursos creada.';
END
ELSE
    PRINT 'ℹ️ Tabla dbo.Cursos ya existe.';
GO

-- Alumnos
IF OBJECT_ID('dbo.Alumnos', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Alumnos (
        AlumnoID INT PRIMARY KEY,
        AlumnoNombre NVARCHAR(100) NOT NULL,
        CursoID INT REFERENCES dbo.Cursos(CursoID),
        Usuario SYSNAME NULL
    );
    PRINT '✅ Tabla dbo.Alumnos creada.';
END
ELSE
    PRINT 'ℹ️ Tabla dbo.Alumnos ya existe.';
GO

-- Matriculas
IF OBJECT_ID('dbo.Matriculas', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Matriculas (
        MatriculaID INT IDENTITY(1,1) PRIMARY KEY,
        AlumnoID INT NOT NULL REFERENCES dbo.Alumnos(AlumnoID),
        CursoID INT NOT NULL REFERENCES dbo.Cursos(CursoID)
    );
    PRINT '✅ Tabla dbo.Matriculas creada.';
END
ELSE
    PRINT 'ℹ️ Tabla dbo.Matriculas ya existe.';
GO

/* =============================================================
   2. INSERCIÓN DE DATOS DE EJEMPLO (solo si no existen)
   ============================================================= */

IF NOT EXISTS (SELECT 1 FROM dbo.Cursos)
BEGIN
    INSERT INTO dbo.Cursos (CursoID, CursoNombre) VALUES 
    (1, 'Matemática'),
    (2, 'Programación'),
    (3, 'Base de Datos');
    PRINT '✅ Datos insertados en dbo.Cursos.';
END

IF NOT EXISTS (SELECT 1 FROM dbo.Alumnos)
BEGIN
    INSERT INTO dbo.Alumnos (AlumnoID, AlumnoNombre, CursoID, Usuario) VALUES
    (1, 'Ana Pérez', 1, 'AnaUser'),
    (2, 'Luis Gómez', 2, 'LuisUser'),
    (3, 'María López', 1, 'MariaUser'),
    (4, 'Carlos Díaz', 3, 'CarlosUser'),
    (5, 'Laura Morales', 1, 'LauraUser');
    PRINT '✅ Datos insertados en dbo.Alumnos.';
END
GO

/* =============================================================
   3. CREAR ESQUEMA "Seguridad"
   ============================================================= */
IF SCHEMA_ID('Seguridad') IS NULL
BEGIN
    EXEC('CREATE SCHEMA Seguridad');
    PRINT '✅ Esquema Seguridad creado.';
END
ELSE
    PRINT 'ℹ️ Esquema Seguridad ya existe.';
GO

/* =============================================================
   4. VISTAS CON SCHEMABINDING
   ============================================================= */

-- Vista 1: Conteo de alumnos por curso
IF OBJECT_ID('Seguridad.VwConteoAlumnosPorCurso', 'V') IS NOT NULL
    DROP VIEW Seguridad.VwConteoAlumnosPorCurso;
GO

CREATE VIEW Seguridad.VwConteoAlumnosPorCurso
WITH SCHEMABINDING
AS
SELECT 
    c.CursoID,
    c.CursoNombre,
    COUNT_BIG(a.AlumnoID) AS TotalAlumnos
FROM dbo.Alumnos a
JOIN dbo.Cursos c ON a.CursoID = c.CursoID
GROUP BY c.CursoID, c.CursoNombre;
GO

-- Vista 2: Promedio del ID de alumnos por curso
IF OBJECT_ID('Seguridad.VwPromedioIDAlumnosPorCurso', 'V') IS NOT NULL
    DROP VIEW Seguridad.VwPromedioIDAlumnosPorCurso;
GO

CREATE VIEW Seguridad.VwPromedioIDAlumnosPorCurso
WITH SCHEMABINDING
AS
SELECT 
    c.CursoID,
    c.CursoNombre,
    AVG(CAST(a.AlumnoID AS FLOAT)) AS PromedioID
FROM dbo.Alumnos a
JOIN dbo.Cursos c ON a.CursoID = c.CursoID
GROUP BY c.CursoID, c.CursoNombre;
GO

/* =============================================================
   5. ÍNDICES Y OPTIMIZACIÓN
   ============================================================= */

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes WHERE name = 'IX_Alumnos_Nombre'
)
BEGIN
    CREATE NONCLUSTERED INDEX IX_Alumnos_Nombre
    ON dbo.Alumnos (AlumnoNombre);
    PRINT '✅ Índice IX_Alumnos_Nombre creado.';
END
ELSE
    PRINT 'ℹ️ El índice IX_Alumnos_Nombre ya existe.';
GO

/* =============================================================
   6. ROW-LEVEL SECURITY
   ============================================================= */

DROP SECURITY POLICY IF EXISTS Seguridad.PoliticaAlumnos;
DROP FUNCTION IF EXISTS Seguridad.fnFiltroAlumnos;
GO

CREATE FUNCTION Seguridad.fnFiltroAlumnos(@Usuario SYSNAME)
RETURNS TABLE
WITH SCHEMABINDING
AS
RETURN SELECT 1 AS fnResult WHERE @Usuario = USER_NAME();
GO

CREATE SECURITY POLICY Seguridad.PoliticaAlumnos
ADD FILTER PREDICATE Seguridad.fnFiltroAlumnos(Usuario)
ON dbo.Alumnos
WITH (STATE = ON);
GO

/* =============================================================
   7. ROLES Y PERMISOS
   ============================================================= */

-- Crear roles si no existen
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'AppReader')
    CREATE ROLE AppReader;
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'AppWriter')
    CREATE ROLE AppWriter;
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'auditorBD')
    CREATE ROLE auditorBD;
GO

-- Otorgar permisos
GRANT SELECT ON dbo.Alumnos TO AppReader;
GRANT SELECT ON dbo.Cursos TO AppReader;
GRANT SELECT ON dbo.Matriculas TO AppReader;

GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.Alumnos TO AppWriter;
GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.Cursos TO AppWriter;
GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.Matriculas TO AppWriter;

GRANT SELECT ON SCHEMA::Seguridad TO auditorBD;
GO

/* =============================================================
   8. SISTEMA DE AUDITORÍA
   ============================================================= */

IF OBJECT_ID('Seguridad.AuditoriaAccesos', 'U') IS NULL
BEGIN
    CREATE TABLE Seguridad.AuditoriaAccesos (
        AuditoriaID INT IDENTITY(1,1) PRIMARY KEY,
        Usuario SYSNAME,
        Accion NVARCHAR(20),
        FechaHora DATETIME DEFAULT GETDATE()
    );
    PRINT '✅ Tabla Seguridad.AuditoriaAccesos creada.';
END
GO

-- Procedimientos
CREATE OR ALTER PROCEDURE Seguridad.Sp_IniciarSesionAlumno
    @Usuario NVARCHAR(50)
AS
BEGIN
    INSERT INTO Seguridad.AuditoriaAccesos (Usuario, Accion)
    VALUES (@Usuario, 'LOGIN');
    PRINT 'Inicio de sesión registrado para: ' + @Usuario;
END;
GO

CREATE OR ALTER PROCEDURE Seguridad.Sp_CerrarSesionAlumno
    @Usuario NVARCHAR(50)
AS
BEGIN
    INSERT INTO Seguridad.AuditoriaAccesos (Usuario, Accion)
    VALUES (@Usuario, 'LOGOUT');
    PRINT 'Cierre de sesión registrado para: ' + @Usuario;
END;
GO

/* =============================================================
   9. TABLA DE BACKUPS Y SIMULACIÓN
   ============================================================= */

IF OBJECT_ID('Seguridad.RegistroBackups', 'U') IS NULL
BEGIN
    CREATE TABLE Seguridad.RegistroBackups (
        BackupID INT IDENTITY(1,1) PRIMARY KEY,
        TipoBackup NVARCHAR(50),
        RutaArchivo NVARCHAR(255),
        Fecha DATETIME DEFAULT GETDATE()
    );
    PRINT '✅ Tabla Seguridad.RegistroBackups creada.';
END
GO

DECLARE @RutaFull NVARCHAR(255) = 'C:\Simulado\Academia2022_FULL.bak';
DECLARE @RutaDif NVARCHAR(255) = 'C:\Simulado\Academia2022_DIF.bak';

INSERT INTO Seguridad.RegistroBackups (TipoBackup, RutaArchivo)
VALUES ('FULL', @RutaFull), ('DIFERENCIAL', @RutaDif);
GO

PRINT '✅ Script maestro completado exitosamente.';
GO
